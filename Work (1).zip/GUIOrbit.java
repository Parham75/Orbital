/**
 * Template class for GUI making use of an external class listener
 * 1 Write own listener registration method for components to be listened to
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIOrbit extends JFrame 
{
    vec R,V;
    double deltat=100;
    double G = 6.67*Math.pow(10,-11);
    double M = 5.97*Math.pow(10,24);
    JButton JbDraw = new JButton("Draw");
    vec Vector;
  //instance variables
  //those menu items which need to be referenced in listener are declared here
//   JLabel jlSemiMajor = new JLabel();
//   JTextField jtfSemiMajor = new JTextField(20);
  JLabel jl2 = new JLabel();
//   JButton jb1 = new JButton("btn 1");
//   JButton jb2 = new JButton("btn 2");
  Maneuvers man = new Maneuvers();
  JPanel content;
    orbitPanel op;
//     PaintPage pp;
    pos pi,pf;
   /**
     * constructor - set up GUI components in constructor
     */
    public GUIOrbit(pos a,pos b)
    {
        super("GUI Orbit");
       pi=a;
       pf=b;
        
         // add content, set layout 
          content = new JPanel();
//           op = new orbitPanel(PI,PF,R,V);
          content.setLayout(new BorderLayout());
          
//            pp = new PaintPage(pi,pf);
//           content.add(pp, BorderLayout.CENTER);
          
          this.setContentPane(content);
//           content.add(jb1);
//           content.add(jb2);
//           content.add(jlSemiMajor);
//           content.add(jtfSemiMajor);
           content.add(JbDraw, BorderLayout.PAGE_START);
          
     
    }//end GUImvcOne constructor

}//end GUImvcOne class
