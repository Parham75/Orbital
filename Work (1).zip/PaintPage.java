// import java.awt.*;
// 
// import javax.swing.*;
// import java.util.Scanner;
// import java.awt.event.ActionEvent;
// import java.awt.event.ActionListener;
// 
// /**
//  * Write a description of class PaintPage here.
//  * 
//  * @author (your name) 
//  * @version (a version number or a date)
//  */
// public class PaintPage extends JPanel implements ActionListener
// {
//     // instance variables - replace the example below with your own
//     private double x1,y1,z1;
//     pos pi,pf;
//     vec Vector;
//     JPanel p;
//     public PaintPage(pos a,pos b)
//     {
//         super();
//         pi = a;
//         pf = b;
//             p = this;
//     }
//     public void actionPerformed(ActionEvent e)
//             {
//                
//                 acc=-(man.mu)/(Math.pow(Vector.getMag(r), 2));
//                 accel = Vector.getSCpro(r, acc/Vector.getMag(r));
//                 if(f<(man.getP(pi)/2+5) && f>(man.getP(pi)/2-5)){
//                     v=Vector.getSum(v,hoh.getHohdv1(pf,pi));
//                 }
//                 if(f<(time+5) && f>(time-5)){
//                     v=Vector.getSum(v,hoh.getHohdv2(pi,pf));
//                 }
//                 r=Vector.getSum(r,Vector.getSCpro(v,10));
//                 v=Vector.getSum(v,Vector.getSCpro(accel,10));
//                 x1=(int)r.x;y1=(int)r.y;z1=(int)r.z;
//                         
//                 p.repaint();
//             }
//     public void drawpp(){
//             Maneuvers man = new Maneuvers();
//             
//             double acc=0;
//             Hohmann hoh = new Hohmann();
//             vec accel = new vec(0,0,0),
//                     r = new vec(0,0,0),
//                     v = new vec(0,0,0);
//             r = man.getvr(pi);
//             v = man.getvv(pi);
//             x1=(int)r.x;y1=(int)r.y;z1=(int)r.z;
//             double time = (man.getP(hoh.posHoh1(pi,pf)))/2+man.getP(pi)/2;
//             for(double f=0;f<20;f+=10){
//                 
//                 
//                 Timer timer = new Timer(1, this);
// 
//    
//             
//                 
//             //System.out.printf(" x = %f y= %f , Vx= %f , Vy=%f ,f=%f,P=%f, time=%f\n",r.x,r.y,r.z,v.x,v.y,v.z,f,man.getP(pi),time);
// //          try {
// //                      Thread.sleep(1);
// //                  } catch (InterruptedException e) {
// //                      e.printStackTrace();
// //                  }
// //              acc=-(man.mu)/(Math.pow(Vector.getMag(r), 2));
// //              accel = Vector.getSCpro(r, acc/Vector.getMag(r));
// //              if(f<(man.getP(pi)/2+5) && f>(man.getP(pi)/2-5)){
// //                  v=Vector.getSum(v,hoh.getHohdv1(pf,pi));
// //              }
// //              if(f<(time+5) && f>(time-5)){
// //                  v=Vector.getSum(v,hoh.getHohdv2(pi,pf));
// //              }
// //              r=Vector.getSum(r,Vector.getSCpro(v,10));
// //              v=Vector.getSum(v,Vector.getSCpro(accel,10));
// //              x1=(int)r.x;y1=(int)r.y;z1=(int)r.z;
// //                      
// //              this.repaint();
//             }}
//             
//             protected void paintComponent(Graphics g){
//             int x=0,y=0;
//             g.setColor(Color.blue);
//             g.fillOval(300-5, 500-5, 10, 10);
//             g.fillOval(900-5, 500-5, 10, 10);
//             g.fillOval(1500-5,500-5, 10, 10);
//             g.setColor(Color.red);
//             Maneuvers man = new Maneuvers();
//             pos a = pi;
//             pos b = pf;
//             g.fillOval(300+((int)x1/637800)-4, 500+((int)y1/637800)-4, 8, 8);
//             g.fillOval(900+((int)y1/637800)-4, 500+((int)z1/637800)-4, 8, 8);
//             g.fillOval(1500+((int)x1/637800)-4, 500+((int)z1/637800)-4, 8, 8);
//             g.setColor(Color.green);
//             g.drawLine(300+(int)x1/637800, 500+(int)y1/637800, 300, 500);
//             g.drawLine(900+(int)y1/637800, 500+(int)z1/637800, 900, 500);
//             g.drawLine(1500+(int)x1/637800, 500+(int)z1/637800, 1500, 500);
//             g.setColor(Color.black);
//                 for(double t=0;t<Math.PI*2;t+=0.001){
//                 a = new pos(pi.a,pi.e,pi.i,t,pi.lon,pi.per);
//                 b= new pos(pf.a,pf.e,pf.i,t,pf.lon,pf.per);
//             g.drawOval((int)(man.getvr(a).x/637800)+300, (int)(man.getvr(a).y/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(b).x/637800)+300, (int)(man.getvr(b).y/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(a).y/637800)+900, (int)(man.getvr(a).z/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(b).y/637800)+900, (int)(man.getvr(b).z/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(a).x/637800)+1500, (int)(man.getvr(a).z/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(b).x/637800)+1500, (int)(man.getvr(b).z/637800)+500, 1, 1);
//             }
// 
// }}
