
/**
 * Write a description of class pos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pos
{
    // instance variables - replace the example below with your own
    public double a,e,i,anom,lon,per;

    /**
     * Constructor for objects of class pos
     */
    public pos(double a,double e, double i,double anom, double lon,double per)
    {
        // initialise instance variables
        this.a = a;
		this.e = e;
		this.i = i;
		this.anom = anom;
		this.lon = lon;
		this.per = per;
    }
}
