import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GUIInput extends JFrame 
{
  //instance variables
  //those menu items which need to be referenced in listener are declared here
  JLabel jla = new JLabel("Length of Semi Major Axis");
  JTextField jtfa = new JTextField(10);
//   JLabel jle = new JLabel("Eccentricity");
//   JTextField jtfe = new JTextField(7);
//   JLabel jli = new JLabel("Angle of Inclination");
//   JTextField jtfi = new JTextField(5);
//   JLabel jllon = new JLabel("longtitude of the Ascending Node");
//   JTextField jtflon = new JTextField(5);
//   JLabel jlper = new JLabel("Angle Between Periapsis and Ascending Node");
//   JTextField jtfper = new JTextField(5);
  
  JLabel jla2 = new JLabel("Length of Semi Major Axis 2");
  JTextField jtfa2 = new JTextField(10);
//   JLabel jle2 = new JLabel("Eccentricity");
//   JTextField jtfe2 = new JTextField(10);
  
  
  JButton jbSubmit = new JButton("Submit");
  JButton jbClose = new JButton("Close");
  
    public GUIInput()
    {
        super("GUI Input");
         // add content, set layout 
          JPanel content = new JPanel();
          this.setContentPane(content);
          
          content.add(jla,BorderLayout.LINE_START);
          content.add(jtfa,BorderLayout.LINE_END);
//           content.add(jle,BorderLayout.LINE_START);
//           content.add(jtfe,BorderLayout.LINE_END);
//           content.add(jli,BorderLayout.LINE_START);
//           content.add(jtfi,BorderLayout.LINE_END);
//           content.add(jllon,BorderLayout.LINE_END);
//           content.add(jtflon,BorderLayout.CENTER);
//           content.add(jlper,BorderLayout.LINE_END);
//           content.add(jtfper,BorderLayout.CENTER);
          
          content.add(jla2);
          content.add(jtfa2);
//           content.add(jle2);
//           content.add(jtfe2);
          
          content.add(jbSubmit);
          content.add(jbClose);
          
     
    }//end GUImvcOne constructor
   
}//end GUImvcOne class
