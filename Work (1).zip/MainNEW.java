/**
 * Main - creates two GUIs and one Controller
 * 1 Create GUI object for each GUI
 * 2 IF want to make use of non static logic methods - and create a Logic object
 * 3 Create Controller object and pass in GUI variables so Controller can listen and refer to them (and perkaps Logic variable)
 */

import javax.swing.JFrame;
public class MainNEW
{
    public static pos pi,pf;
    
    public static void main(String[] args)
    {
        GUIInput win1 = new GUIInput();
        GUIOrbit go = new GUIOrbit();

        //Logic l = new Logic();  //for Logic object - or use non static Logic methods
        Controller con = new Controller(win1);
        win1.setSize(300,500);
        win1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win1.setVisible(true);
        
    }//end main    
    
}//endclass GUIMain