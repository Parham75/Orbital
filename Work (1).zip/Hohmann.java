
/**
 * Write a description of class Hohmann here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hohmann extends Maneuvers
{

    public Hohmann()
    {

    }
    // Position of the satellite just before the impulse
        public pos posHoh1(pos x,pos y){
        double RP = (x.a*(1-x.e))
            ,  a = (RP+y.a)/2
            ,  e = 1-2*RP/(RP+y.a)
            ,  i = x.i
            ,  per = 0
            ,  lon = x.lon
            ,  anom = 0;
        pos res = new pos(a,e,i,anom,lon,per);
        return res;
    }
    // Position of the satellite just after the impulse
    public pos posHoh2(pos x,pos y){
        double RP = (x.a*(1-x.e))
            ,  a = (RP+y.a)/2
            ,  e = 1-2*RP/(RP+y.a)
            ,  i = x.i
            ,  per = 0
            ,  lon = x.lon
            ,  anom = Math.PI;
        pos res = new pos(a,e,i,anom,lon,per);
        return res;
    }
    // Position of the satellite just before the second impulse
    public pos posHoh3(pos x,pos y){
        double a = y.a
            ,  e = 0
            ,  i = x.i
            ,  per = 0
            ,  lon = x.lon
            ,  anom = Math.PI+x.per;
        pos res = new pos(a,e,i,anom,lon,per);
        return res;
    }
    // Vector of the first impulse per unit mass
        public vec getHohdv1(pos a,pos b){
        vec res = vec.getSub(getvv(posHoh1(a,b)),getvv(a));
        return res;
    }
    // Vector of the second impulse per unit mass
    public vec getHohdv2(pos a,pos b){
        vec res = vec.getSub(getvv(posHoh3(a,b)),getvv(posHoh2(a,b)));
        return res;
    }
    // Energy needed for the transfer
    public double getEnergyHoh(pos a,pos b){
        double E = (mu/(2*a.a)-mu/(2*b.a));
        return E;
    }
}
