/**
 * Controller 
 *
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
public class Controller implements ActionListener 
{
    GUIInput input;
    GUIOrbit go;
    public pos pi,pf;
    orbitPanel op;
    //constructor
    public Controller(GUIInput guiOne)
    {
        // construct the GUI views
        this.input = guiOne;
        

        // Add listener to buttons of each GUI
        input.jbSubmit.addActionListener(this);

    }//end constructor
    public void actionPerformed(ActionEvent ae) 
    {
        if (ae.getSource()==input.jbSubmit) 
        {
             
            double a = Double.parseDouble(input.jtfa.getText());
//             double e = Double.parseDouble(input.jtfe.getText());
//             double i = Double.parseDouble(input.jtfi.getText());
//             double lon = Double.parseDouble(input.jtflon.getText());
//             double per = Double.parseDouble(input.jtfper.getText());
            
            double a2 = Double.parseDouble(input.jtfa2.getText());
//             double e2 = Double.parseDouble(input.jtfe2.getText());
            
            pi = new pos(a,0,0,0,0,0);
            pf = new pos(a2,0,0,0,0,0);
            input.setVisible(false);
            op = new orbitPanel(pi,pf);
//             go = new GUIOrbit(pi,pf);
            
//              go.setSize(1000,1000);
//              go.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//              go.setVisible(true);
//               go.draw();

            }

       
//         Logic.doSomething(); //for static method, for non static would need Logic object 'variable'
//         count++;
//         viewB.jl3.setText("count: "+ count); 
    }//end actionPerformed
}//end controller class
