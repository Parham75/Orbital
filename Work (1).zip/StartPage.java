import javax.swing.*;

public class StartPage extends JFrame {
	JButton JB1 = new JButton("Welcome to the Orbital Maneuver Calculator ");
	JButton JB2 = new JButton("JB2");
	JLabel JL1 = new JLabel("JL1");
    JLabel JL2 = new JLabel("JL2");
    JLabel JL3 = new JLabel("JL3");
    
    public StartPage(){
    	super();
    	
    	JPanel content = new JPanel();
        this.setContentPane(content);
        content.add(JB1);
        content.add(JB2);
        content.add(JL1);
        content.add(JL2);
        content.add(JL3);
    }
}
