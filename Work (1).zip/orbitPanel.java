import java.awt.*;
import javax.swing.*;
public class orbitPanel extends JPanel 
{
    Maneuvers man = new Maneuvers();
    double x1,y1,z1,deltat=10;
    vec R,V,Vector;
    pos Pi,Pf;
    double G = 6.67*Math.pow(10,-11),
           M = 5.97*Math.pow(10,24);
    
    public orbitPanel(pos pi,pos pf){
        Pi=pi;Pf=pf;
        repaint();
        this.setLayout(null);
        this.setLocation(0,0);
        this.setVisible(true);
        this.setSize(new Dimension(1000,1000));
        JFrame frame = new JFrame();
         Maneuvers man = new Maneuvers();
            frame.setTitle("Projectile practice");
            frame.setSize(1000,1000);
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            orbitPanel op = new orbitPanel(pi,pf);
            frame.setContentPane(op);
           draw();
               
    }
           public void draw(){
        R = man.getvr(Pi);V=man.getvv(Pf);
        
                for(int t=0;t<=50000;t+=deltat){
                    repaint();

                        try {
                            Thread.sleep(10);
                        } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            R=integratorOfRadius(R,V);
                            V=integratorOfVelocity(R,V);
                            System.out.println(R.x);}}
   public vec integratorOfRadius(vec prevRad,vec Vel){
       vec Radius = Vector.getSum(prevRad,Vector.getSCpro(Vel,deltat));
       return Radius;
    }
    
    public vec integratorOfVelocity(vec prevRad,vec prevVel){
        double accel3 = -G*M/Math.pow(Vector.getMag(prevRad),3);
       vec acceleration = Vector.getSCpro(prevRad,accel3);
       vec velocity = Vector.getSum(prevVel,Vector.getSCpro(acceleration,deltat));
        return velocity;
    }

        
    //overrides paintComponent method and calls drawflag method
    @Override
    public void paintComponent(Graphics g) 
    {
        super.paintComponent(g);
        
            
            g.setColor(Color.blue);
            g.fillOval(500-5, 500-5, 10, 10);
//             g.fillOval(900-5, 500-5, 10, 10);
//             g.fillOval(1500-5,500-5, 10, 10);
            g.setColor(Color.red);
            g.fillOval(500+((int)R.x/637800)-4, 500+((int)R.y/637800)-4, 8, 8);
//             g.fillOval(900+((int)R.y/637800)-4, 500+((int)R.z/637800)-4, 8, 8);
//             g.fillOval(1500+((int)R.x/637800)-4, 500+((int)R.z/637800)-4, 8, 8);
            g.setColor(Color.green);
            g.drawLine(500+(int)R.x/637800, 500+(int)R.y/637800, 500, 500);
//             g.drawLine(900+(int)R.y/637800, 500+(int)R.z/637800, 900, 500);
//             g.drawLine(1500+(int)R.x/637800, 500+(int)R.z/637800, 1500, 500);
            g.setColor(Color.black);
                for(double t=0;t<Math.PI*2;t+=0.001){
              pos  a = new pos(Pi.a,Pi.e,Pi.i,t,Pi.lon,Pi.per);
              pos b= new pos(Pf.a,Pf.e,Pf.i,t,Pf.lon,Pf.per);
            g.drawOval((int)(man.getvr(a).x/637800)+500, (int)(man.getvr(a).y/637800)+500, 1, 1);
            g.drawOval((int)(man.getvr(b).x/637800)+500, (int)(man.getvr(b).y/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(a).y/637800)+900, (int)(man.getvr(a).z/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(b).y/637800)+900, (int)(man.getvr(b).z/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(a).x/637800)+1500, (int)(man.getvr(a).z/637800)+500, 1, 1);
//             g.drawOval((int)(man.getvr(b).x/637800)+1500, (int)(man.getvr(b).z/637800)+500, 1, 1);
   }}
    //override method to return preferred size - called when graphic is redrawn

}
